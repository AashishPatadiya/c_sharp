﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace boxing_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            //boxing
            int i = 10;
            object a1 = i;
            Console.WriteLine("boxing:" + "   " + a1);

            //unboxing
            int j = (int)a1;
            Console.WriteLine("unboxing:" + " " + j);
            Console.Read();
        }
    }
}
