﻿//rec.array(user input)
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] mat = new int[3, 3];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("enter the value:");
                    mat[i, j] = Int32.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine();
            Console.Write("*matrix*");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine();
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(mat[i, j] + " ");
                }
            }
            Console.Read();
        }
    }
}

